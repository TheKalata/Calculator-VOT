async function calculate() {
    const expression = document.getElementById('expression').value;
    const resultDiv = document.getElementById('result');

    try {
        const response = await fetch('http://localhost:5000/calculate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ expression }),
        });

        const data = await response.json();

        if (response.ok) {
            resultDiv.textContent = `Result: ${data.result}`;
        } else {
            resultDiv.textContent = `Error: ${data.error}`;
        }
    } catch (error) {
        resultDiv.textContent = `Error: ${error.message}`;
    }
}
