grant all privileges on *.* to 'kalata'@'%';
flush privileges;

create database if not exists backend;
